package com.example.ms.service;

import com.example.ms.model.User;
import com.example.ms.repository.UserRepository;
import com.example.ms.service.Interfaces.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService implements IUserService {
    @Autowired
    private UserRepository userRepository;

    @Override
    public void saveUser(User user){
        userRepository.save(user);
    }

    @Override
    public User getUserDetailsByUserName(String userName){
        return userRepository.findById(userName).orElse(null);
    }

    @Override
    public User updateUserDetails(final User user){
        final User userData = userRepository.findById(user.getUserName()).orElse(null);
        if(userData != null){
            userData.setFirstName(user.getFirstName());
            userData.setSecondName(user.getSecondName());
            userData.setGender(user.getGender());
            userRepository.save(userData);
            return userData;
        }

        return null;
    }

    @Override
    public String getUserNameByEmail(String email){
        final String userName = userRepository.findUserNameByEmail(email);
        return userName != null ? userName : "InvalidEmail";
    }
}
