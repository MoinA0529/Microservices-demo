package com.example.ms.service.Interfaces;

import com.example.ms.model.User;

public interface IUserService {
    public void saveUser(User user);

    public User getUserDetailsByUserName(String userName);

    public User updateUserDetails(User user);

    public String getUserNameByEmail(String email);
}
