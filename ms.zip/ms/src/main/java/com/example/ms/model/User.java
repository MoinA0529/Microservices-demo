package com.example.ms.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class User {
    @Id
    private String userName;
    @Column
    private String firstName;
    @Column
    private String SecondName;
    @Column
    private String Gender;
    @Column
    private String Email;

    public User() {

    }
    public User(String userName, String firstName, String secondName, String gender, String email) {
        super();
        this.userName = userName;
        this.firstName = firstName;
        this.SecondName = secondName;
        this.Gender = gender;
        this.Email = email;
    }

    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getSecondName() {
        return SecondName;
    }
    public void setSecondName(String secondName) {
        this.SecondName = secondName;
    }
    public String getGender() {
        return Gender;
    }
    public void setGender(String gender) {
        this.Gender = gender;
    }
    public void setEmail(String email){
        this.Email = email;
    }
    public String getEmail(){
        return Email;
    }

}
